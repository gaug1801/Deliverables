import java.io.File;
import java.io.PrintWriter;
import java.util.*;

// Class DelivD does the work for deliverable DelivD of the Prog340

public class DelivD {

	File inputFile;
	File outputFile;
	static PrintWriter out;
	static Graph g;

	static Graph h;
	
	public DelivD( File in, Graph gr, Graph hg) {
		inputFile = in;
		g = gr;
		h = hg;

		
		// Get output file name.
		String inputFileName = inputFile.toString();
		String baseFileName = inputFileName.substring( 0, inputFileName.length()-4 ); // Strip off ".txt"
		String outputFileName = baseFileName.concat( "_out.txt" );
		outputFile = new File( outputFileName );
		if (outputFile.exists()) {    // For retests
			outputFile.delete();
		}
		
		try {
			out = new PrintWriter(outputFile);
		}
		catch (Exception x ) { 
			System.err.format("Exception: %s%n", x);
			System.exit(0);
		}

		heuristicSearch(g, h);
		out.flush();
	}

	public static void heuristicSearch(Graph graph, Graph hGraph) {
		Node startNode = null;
		Node endNode = null;

		//find the start and end nodes
		for (Node a : graph.getNodeList()) {
			if (a.getVal().equalsIgnoreCase("S")) {
				startNode = a;
			} else if (a.getVal().equalsIgnoreCase("G")) {
				endNode = a;
			}
		}

		//confirm the search has a start and end node before
		if (startNode == null || endNode == null) {
			System.out.println("Start or end node not found.");
			out.println("Start or end node not found.");
			return;
		}


		PriorityQueue<Path> queue = new PriorityQueue<>();	//main priority queue
		Map<Node, Path> visited = new HashMap<>();	//keep track of visited nodes and the best path to it
		ArrayList<Node> finished = new ArrayList<>();	//keep track of all finished nodes

		//create degenerate start path
		ArrayList<Edge> startPathList = new ArrayList<>();
		startPathList.add(new Edge(startNode, startNode, 0, 0));
		Path startPath = new Path(startPathList, 0, startNode);

		//add the start path to the priority queue and mark this path as the best path to start node
		queue.add(startPath);
		visited.put(startNode, startPath);

		//start output
		System.out.printf("%-20s %-10s %-10s %-10s%n", "PATH", "DIST", "HEUR", "F-VALUE");
		System.out.printf("%-20s %-10d %-10d %-10d\n%n", startPath, startPath.getDist(), startPath.getHeur(), (startPath.getDist() + startPath.getHeur()));
		out.printf("%-20s %-10s %-10s %-10s%n", "PATH", "DIST", "HEUR", "F-VALUE");
		out.printf("%-20s %-10d %-10d %-10d\n%n", startPath, startPath.getDist(), startPath.getHeur(), (startPath.getDist() + startPath.getHeur()));

		while (!queue.isEmpty()) {
			Path currPath = queue.poll();
			Node currNode = currPath.getEndNode();

			visited.put(currNode, currPath); //mark this as the best path to this current end node

			if (currNode.equals(endNode)) {
				System.out.printf("%-20s %-10d%n", currPath, currPath.getDist());
				out.printf("%-20s %-10d%n", currPath, currPath.getDist());
				return;
			}

			for (Edge e : currNode.getOutgoingEdges()) {
				Node newNode = e.getHead();
				int newDist = currPath.getDist() + e.getDist();

				if (newNode.equals(endNode)) {	//second goal node check to detect it the moment we find it
					ArrayList<Edge> newPath = new ArrayList<>(currPath.getPath());
					newPath.add(e);
					Path nextPath = new Path(newPath, newDist, e.getHeur(), newNode); //Create new path with the new city at the end

					System.out.printf("%-20s %-10d%n", nextPath, nextPath.getDist());
					out.printf("%-20s %-10d%n", nextPath, nextPath.getDist());
					return;
				} else if (!visited.containsKey(newNode) || newDist < visited.get(newNode).getDist()) { //If the node hasn't been visited or this is a better path, add it to the priority queue

					ArrayList<Edge> newPath = new ArrayList<>(currPath.getPath());
					newPath.add(e);

					//determine the heuristic of the path to be added to the priority queue
					int newHeur = 0;
					for (Edge hEdge : hGraph.getEdgeList()) {
						if (hEdge.getTail().getAbbrev().compareToIgnoreCase(newNode.getAbbrev()) == 0
								&& hEdge.getHead().getAbbrev().compareToIgnoreCase(endNode.getAbbrev()) == 0) {
							newHeur = hEdge.getDist();
							break;
						}
					}

					Path nextPath = new Path(newPath, newDist, newHeur, newNode);	//create new path with the new city at the end and updated values
					visited.put(newNode, nextPath);
					queue.add(nextPath);	//add path to the priority queue

					System.out.printf("%-20s %-10d %-10d %-10d\n", visited.get(newNode).toString(), visited.get(newNode).getDist(), newHeur, (visited.get(newNode).getDist() + newHeur));
					out.printf("%-20s %-10d %-10d %-10d\n", visited.get(newNode).toString(), visited.get(newNode).getDist(), newHeur, (visited.get(newNode).getDist() + newHeur));

				} else if (!finished.contains(newNode)) {	//print the undesired path without enqueuing it

					ArrayList<Edge> newPath = new ArrayList<>(currPath.getPath());
					newPath.add(e);
					Path nextPath = new Path(newPath, newDist, e.getHeur(), newNode);

					System.out.printf("%-20s %-10d\n", nextPath, newDist);
					out.printf("%-20s %-10d\n", nextPath, newDist);
					}

			}
			System.out.println();
			out.println();
			finished.add(currNode); //the node at the current path being explored is "finished" - all outgoing edges explored
		}
		System.out.println("No path found.");
		out.println("No path found.");
	}
}
