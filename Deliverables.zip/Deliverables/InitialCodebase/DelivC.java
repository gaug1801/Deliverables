import java.io.File;
import java.io.PrintWriter;
import java.util.*;

// Class DelivC does the work for deliverable DelivC of the Prog340

public class DelivC {

	File inputFile;
	File outputFile;
	static PrintWriter output;
	static Graph g;

	public DelivC(File in, Graph gr) {
		inputFile = in;
		g = gr;

		// Get output file name.
		String inputFileName = inputFile.toString();
		String baseFileName = inputFileName.substring(0, inputFileName.length() - 4); // Strip off ".txt"
		String outputFileName = baseFileName.concat("_out.txt");
		outputFile = new File(outputFileName);
		if (outputFile.exists()) {    // For retests
			outputFile.delete();
		}

		try {
			output = new PrintWriter(outputFile);
		} catch (Exception x) {
			System.err.format("Exception: %s%n", x);
			System.exit(0);
		}

		lowestCostFirstSearch();
		output.flush();
	}

	public static void lowestCostFirstSearch() {
		Graph graph = g;
		Node startNode = null;
		Node endNode = null;

		//Find start and end nodes based on the nodes with the "S" and "G" values in the graph.
		for (Node a : graph.getNodeList()) {
			if (a.getVal().compareToIgnoreCase("S") == 0) {
				startNode = a;
			}
		}

		for (Node e : graph.getNodeList()) {
			if (e.getVal().compareToIgnoreCase("G") == 0) {
				endNode = e;
			}
		}
		//Create degenerate start path
		ArrayList<Edge> startPathList = new ArrayList<>();
		startPathList.add(new Edge(startNode, startNode, 0));
		Path startPath = new Path(startPathList, 0, startNode);

		PriorityQueue<Path> queue = new PriorityQueue<>();
		Map<Node, Path> visited = new HashMap<>();
		ArrayList<Node> finished = new ArrayList<>();
		queue.add(startPath);

		//Initiating the chart to print, set the start node as visited
		System.out.println("PATH                             DIST                   CITY\tMIN_DIST        PATH");
		System.out.printf("%-35s %-8d\n", startPath.toString(), startPath.getDist());
		output.println("PATH                             DIST                   CITY\tMIN_DIST        PATH");
		output.printf("%-35s %-8d\n", startPath.toString(), startPath.getDist());
		visited.put(startNode, startPath);

		//Iterate through the best path
		while (!queue.isEmpty()) {
			Path currPath = queue.poll();
			Node currNode = currPath.getEndNode();

			if (finished.contains(currNode)) {
				continue;
			}

			//Print out the best path to the end node
			if (currNode.equals(endNode)) {
				System.out.printf("%60s\t%-13d\t%7s\n", currNode.getName(), currPath.getDist(), currPath.toString());
				output.printf("%60s\t%-13d\t%7s\n", currNode.getName(), currPath.getDist(), currPath.toString());
				return;
			}
			//Print the current city, cost to get to the city, and the path to that city
			System.out.printf("%60s\t%-13d\t%7s\n", currNode.getName(), currPath.getDist(), currPath.toString());
			output.printf("%60s\t%-13d\t%7s\n", currNode.getName(), currPath.getDist(), currPath.toString());

			//Iterate through all the outgoing edges from the current best path
			for (Edge e : currNode.getOutgoingEdges()) {
				Node nextNode = e.getHead();
				int newCost = currPath.getDist() + e.getDist();

				//Ensure the node has not been visited, that the cost is better than what we currently have stored, and the node has not been finished yet
				if (!visited.containsKey(nextNode) || newCost < visited.get(nextNode).getDist() || !finished.contains(nextNode)){
					ArrayList<Edge> newPath = new ArrayList<>(currPath.getPath());
					newPath.add(e);
					Path nextPath = new Path(newPath, newCost, nextNode); //Create new path with the new cities at the end
					queue.add(nextPath); //Add path to the priority queue
					visited.put(nextNode, nextPath);
					System.out.printf("%-35s %-8d\n", visited.get(e.getHead()).toString(), visited.get(e.getHead()).getDist());
					output.printf("%-35s %-8d\n", visited.get(e.getHead()).toString(), visited.get(e.getHead()).getDist());
				}
			}
			finished.add(currNode); //Add the city to finished once all the necessary paths have been added to the priority queue
		}
	}
}













