import java.util.ArrayList;

public class Path implements Comparable<Path>{
     public ArrayList<Edge> path = new ArrayList<Edge>();
     private int pathDist;
     private int pathHeur;
     private Node endNode;
     private int fVal; // use this val to compare the paths for the PQ


     public Path(ArrayList<Edge> newPath, int newCost, Node newEndNode) {
         this.path = newPath;
         this.pathDist = newCost;
         this.endNode = newEndNode;
     }

    public Path(ArrayList<Edge> newPath, int newCost, int heuristicCost, Node newEndNode) {
        this.path = newPath;
        this.pathDist = newCost;
        this.endNode = newEndNode;
        this.pathHeur = heuristicCost;
        this.fVal =  newCost + heuristicCost;
    }

    public Node getEndNode() {return endNode;}
    public ArrayList<Edge> getPath(){
         return path;
    }
    public int getDist() {return pathDist;}
    public int getfVal(){return getDist() + getHeur();}

    public int getHeur() {return pathHeur;}

    public String toString() {
         String res = "";
         for (Edge e : this.getPath()) {
             res += e.getHead().getAbbrev() + "->";
         }
         res = res.substring(0, res.length() - 2);
         return res;
    }

    //Based on
    @Override
    public int compareTo(Path o) {
        if (getHeur() == 0 ) {
            if (this.pathDist > o.getDist()) {
                return 1;
            }
            if (this.pathDist < o.getDist()) {
                return -1;
            }
        }

        else {
            if (this.fVal > o.getfVal()) {
                return 1;
            }
            if (this.fVal < o.getfVal()) {
                return -1;
            }
        }
        return 0;
    }
}
