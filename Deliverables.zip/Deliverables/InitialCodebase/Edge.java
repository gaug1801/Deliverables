
public class Edge implements Comparable<Edge>{

	int dist;
	int heur;
	Node tail;
	Node head;

	public Edge( Node tailNode, Node headNode, int dist ) {
		setDist( dist );
		setTail( tailNode );
		setHead( headNode );
	}
	public Edge( Node tailNode, Node headNode, int dist, int heur) {
		setDist( dist );
		setTail( tailNode );
		setHead( headNode );
		setHeur(heur);
	}

	public Node getTail() {
		return tail;
	}

	public Node getHead() {
		return head;
	}

	public int getDist() {
		return dist;
	}

	public void setTail( Node n ) {
		tail = n;
	}

	public void setHead( Node n ) {
		head = n;
	}

	public void setDist( int i ) {
		dist = i;
	}

	public int getHeur() {
		return this.heur;
	}
	public void setHeur(int newHeur) {
		this.heur = newHeur;
	}

	public String toString() {
		return tail.getAbbrev()  + "->" + head.getAbbrev() + "; Distance: " + dist + "\n";
	}

	@Override
	public int compareTo(Edge o) {
		if (this.getDist() > o.getDist()) {
			return 1;
		}
		if (this.getDist() < o.getDist()) {
			return -1;
		}
		return 0;
	}
}

