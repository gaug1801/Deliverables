import java.io.*;
import java.util.Scanner;

// Class DelivA does the work for deliverable DelivA of the Prog340

public class DelivA {

    File inputFile;
    File outputFile;
    PrintWriter output;
    Graph g;

    public DelivA(File in, Graph gr) {
        inputFile = in;
        g = gr;

        // Get output file name.
        String inputFileName = inputFile.toString();
        String baseFileDirectory = inputFileName.substring(0, inputFileName.length() - 4); // Strip off ".txt"
        String outputFileName = baseFileDirectory.concat("_out.txt");
        outputFile = new File(outputFileName);
        if (outputFile.exists()) {    // For retests
            outputFile.delete();
        }

        try {

            output = new PrintWriter(outputFile);

            //Format graph name.
            String baseFileName = baseFileDirectory.substring(baseFileDirectory.length() - 3, baseFileDirectory.length());
            String info = "Graph " + baseFileName + ":\n";

            //Print all graph information.
            info += gr.printGraphInfo();

            //Print to file and to console.
            output.println(info);
            System.out.println(info);


            output.close();
        } catch (Exception x) {
            System.err.format("Exception: %s%n", x);
            System.exit(0);
        }

        output.flush();


    }


}
