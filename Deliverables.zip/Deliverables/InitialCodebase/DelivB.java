import java.io.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

// Class DelivB does the work for deliverable DelivB of the Prog340
public class DelivB {
	File inputFile;
	File outputFile;
	static PrintWriter output;
	static Graph g;
	static final Integer MAX_VAL = Integer.MAX_VALUE;

	public DelivB(File in, Graph gr) {
		inputFile = in;
		g = gr;

		// Get output file name.
		String inputFileName = inputFile.toString();
		String baseFileName = inputFileName.substring(0, inputFileName.length() - 4); // Strip off ".txt"
		String outputFileName = baseFileName.concat("_out.txt");
		outputFile = new File(outputFileName);
		if (outputFile.exists()) {    // For retests
			outputFile.delete();
		}

		try {
			output = new PrintWriter(outputFile);
		} catch (Exception x) {
			System.err.format("Exception: %s%n", x);
			System.exit(0);
		}

		/* Print charts for dynamic and recursive methods.
		* Although the function is set to find the change of 1 - 100¢,
		* I found difficulty running anything past 1 - 65¢
		* for recursive programming.*/

		printCharts(100);
	}

	/* Brute Force approach to minimum change */
	public static int bruteMinChange(int[] coins, int amount) {
		if (amount == 0) return 0;
		//Set minCoins to placeholder value until min is found
		int minCoins = MAX_VAL;
		for (int coin : coins) {
			if (coin <= amount) {
				int subRes = bruteMinChange(coins, amount - coin);
				//Ensure the result is the new minimum
				if (subRes != MAX_VAL && subRes + 1 < minCoins) {
					minCoins = 1 + subRes;
				}
			}
		}
		return minCoins;
	}

	/* Dynamic Programming approach to minimum change */
	public static int dynamicMinChange(int[] coins, int amount) {
		if (amount == 0) return 0;
		int[] dp = new int[amount + 1];
		Arrays.fill(dp, amount + 1);
		dp[0] = 0;
		//Bottom-up structure
		for (int i = 1; i <= amount; i++) {
			for (int coin : coins) {
				if (coin <= i) {
					//Storing intermediate results
					dp[i] = Math.min(dp[i], dp[i - coin] + 1);
				}
			}
		}
		return dp[amount] > amount ? -1 : dp[amount];
	}

	/* Find the amount needed of each coin for minimum change */
	public static List<Integer> findCoins(int[] coins, int amount) {
		int[] dp = new int[amount + 1];
		Arrays.fill(dp, MAX_VAL);
		dp[0] = 0;
		int[] coinSelection = new int[amount + 1];

		//Bottom-up structure
		for (int i = 1; i <= amount; i++) {
			for (int j = 0; j < coins.length; j++) {
				if (coins[j] <= i) {
					int subRes = dp[i - coins[j]];
					if (subRes != MAX_VAL && subRes + 1 < dp[i]) {
						dp[i] = subRes + 1;
						coinSelection[i] = j;
					}
				}
			}
		}
		//Add results to a list
		List<Integer> result = new ArrayList<>();
		int i = amount;
		while (i > 0) {
			result.add(coins[coinSelection[i]]);
			i -= coins[coinSelection[i]];
		}
		return result;
	}

	//Print Dynamic Programming chart
	public static void dynamicPrint(int amount) {
		//Create int array to carry coin sizes.
		int[] coins = new int[g.getSize()];
		int k = 0;
		//Populate int array with graph values.
		for (Node a : g.getNodeList()) {
			coins[k] = Integer.parseInt(a.getVal());
			k++;
		}

		//Print change chart headers - format is a tad different between console and file.
		System.out.println("|---------- DYNAMIC PROGRAMMING ----------|");
		System.out.print("Change\tCoins\t");
		output.println("|---------------------- DYNAMIC PROGRAMMING ----------------------|");
		output.print("Change\tCoins\t");

		/*If the biggest coin is 60, print coins as pounds.
		Otherwise, print American cents for anything else. */
		if (coins[0] == 60) {
			for (int i = coins.length - 1; i > -1; i--) {
				System.out.print(coins[i] + "p\t");
				output.print(coins[i] + "p\t");
			}
		} else {
			for (int i = coins.length - 1; i >= 0; i--) {
				System.out.print(coins[i] + "¢\t");
				output.print(coins[i] + "¢\t");
			}
		}

		System.out.println();
		output.println();

		//Chart formatting
		List<Integer> minCoins;
		for (int i = 1; i <= amount; i++) {
			System.out.print(i + "\t\t" + dynamicMinChange(coins, i) + "\t\t");
			output.print(i + "\t" + dynamicMinChange(coins, i) + "\t");
			minCoins = findCoins(coins, i);

			int[] coinCount = new int[coins.length];
			Arrays.fill(coinCount, 0);
			for (int f = 0; f < coins.length; f++) {
				for (Integer a : minCoins) {
					if (coins[f] == a) {
						coinCount[f]++;
					}
				}
			}

			for (int a = coins.length - 1; a >= 0; a--) {
				System.out.print(coinCount[a] + "\t");
				output.print(coinCount[a] + "\t");
			}

			System.out.println();
			output.println();

		}
		System.out.println("|------ END OF DYNAMIC PROGRAMMING ------|\n");
		output.println("|------------------ END OF DYNAMIC PROGRAMMING ------------------|\n");
		output.flush();
	}

	public static void bruteForcePrint(int amount) {
		//Create int array to carry coin denominations.
		int[] coins = new int[g.getSize()];
		int k = 0;
		//Populate int array with graph values.
		for (Node a : g.getNodeList()) {
			coins[k] = Integer.parseInt(a.getVal());
			k++;
		}

		//Print change chart headers
		System.out.println("|-------------- BRUTE FORCE --------------|");
		System.out.print("Change\tCoins\t");
		output.println("|-------------------------- BRUTE FORCE ---------------------------|");
		output.print("Change\tCoins\t");

		/*If the biggest coin is 60, print coins as pounds.
		Otherwise, print American cents for anything else. */
		if (coins[0] == 60) {
			for (int i = coins.length - 1; i > -1; i--) {
				System.out.print(coins[i] + "p\t");
				output.print(coins[i] + "p\t");
			}
		} else {
			for (int i = coins.length - 1; i >= 0; i--) {
				System.out.print(coins[i] + "¢\t");
				output.print(coins[i] + "¢\t");
			}
		}

		System.out.println();
		output.println();

		//Chart formatting
		List<Integer> minCoins;
		for (int i = 1; i <= amount; i++) {
			System.out.print(i + "\t\t" + bruteMinChange(coins, i) + "\t\t");
			output.print(i + "\t" + bruteMinChange(coins, i) + "\t");
			minCoins = findCoins(coins, i);

			int[] coinCount = new int[coins.length];
			Arrays.fill(coinCount, 0);
			for (int f = 0; f < coins.length; f++) {
				for (Integer a : minCoins) {
					if (coins[f] == a) {
						coinCount[f]++;
					}
				}
			}

			for (int a = coins.length - 1; a >= 0; a--) {
				System.out.print(coinCount[a] + "\t");
				output.print(coinCount[a] + "\t");
			}

			System.out.println();
			output.println();
		}

		System.out.println("|---------- END OF BRUTE FORCE ----------|\n");
		output.println("|---------------------- END OF BRUTE FORCE  ----------------------|\n");
		output.flush();
	}

	//Calls print chart function for both dynamic programming and recursive algorithm
	public static void printCharts(int change) { bruteForcePrint(change); dynamicPrint(change);}


	//Test runtime of Dynamic Programming and Recursive algorithm
	public static void unitTimeTest(int[] coins, int amount) {
		for (int i = 1; i <= amount; i++) {
			//Dynamic programming
			long startTime = System.nanoTime();
			int result = dynamicMinChange(coins, i);
			long elapsedTime = System.nanoTime() - startTime;
			System.out.println(elapsedTime); // time in nanoseconds
		}

		System.out.println("\n|--------------END OF DYNAMIC PROGRAMMING--------------|");

		for (int i = 1; i <= amount; i++) {
			//Recursive method
			long startTime1 = System.nanoTime();
			int result1 = bruteMinChange(coins, i);
			long elapsedTime1 = System.nanoTime() - startTime1;
			System.out.println(elapsedTime1); // time in nanoseconds
		}
	}

	//Test values from recursive and dynamic programming functions
	public static void unitValueTest(int[] coins, int amount) {
		//Dynamic programming
		for (int i = 1; i <= amount; i++) {
			int result = dynamicMinChange(coins, i);
			System.out.println(result + " coins for minimum change for " + i + " cents"); // time in seconds
		}

		System.out.println("\n|--------------END OF DYNAMIC PROGRAMMING--------------|");

		//Recursive method
		for (int i = 1; i <= amount; i++) {
			int result1 = bruteMinChange(coins, i);
			System.out.println(result1 + " coins for minimum change for " + i + " cents");
		}
	}
}



