import java.util.*;

public class Graph {

	ArrayList<Node> nodeList;
	ArrayList<Edge> edgeList;

	public Graph() {
		nodeList = new ArrayList<Node>();
		edgeList = new ArrayList<Edge>();
	}

	public ArrayList<Node> getNodeList() {
		return nodeList;
	}

	public ArrayList<Edge> getEdgeList() {
		return edgeList;
	}

	public void addNode(Node n) {
		nodeList.add(n);
	}

	public void addEdge(Edge e) {
		edgeList.add(e);
	}


	public int getSize() { return nodeList.size(); }

	public Edge getEdge(int pos) {
		return edgeList.get(pos);
	}

	public Node getNode (int pos) {
		return nodeList.get(pos);
	}



	//Count the amount of nodes with the largest outdegree.
	public int countMaxOutgoingDegreeNodes() {
		int max = findMaxOutdegree();
		int count = 0;
		for (Node a : getNodeList()) {
			if (a.getOutgoingEdges().size() == max) {
				count++;
			}
		}
		return count;
	}


	//Find largest edge distance.
	public int findMaxEdgeDist() {
		int max = 0;
		for (Edge e : this.getEdgeList()) {
			if (e.getDist() > max) {
				max = e.getDist();
			}
		}
		return max;
	}

	//Find the smallest edge distance.
	public int findMinEdgeDist() {
		Integer bigMin = Integer.MAX_VALUE;
		int min = bigMin.intValue();
		if (this.getEdgeList().size() == 0) {
			return min = 0;
		} else {
			for (Edge e : this.getEdgeList()) {
				if (e.getDist() <= min) {
					min = e.getDist();
				}
			}
		}
		return min;
	}

	//Find all edges with the largest distance.
	public ArrayList<Edge> findMaxEdge() {
		String result = "";
		ArrayList<Edge> maxEdges = new ArrayList<Edge>();
		int max = findMaxEdgeDist();
		for (Edge e : this.getEdgeList()) {
			if (e.getDist() == max) {
				maxEdges.add(e);
			}
		}
		return maxEdges;
	}

	//Find all edges with the minimum distance.
	public ArrayList<Edge> findMinEdge() {
		String result = "";
		ArrayList<Edge> minEdges = new ArrayList<Edge>();
		int min = findMinEdgeDist();
		for (Edge e : this.getEdgeList()) {
			if (e.getDist() == min) {
				minEdges.add(e);
			}
		}
		return minEdges;
	}


	//Find the largest outdegree.
	public int findMaxOutdegree() {
		Integer bigMax = Integer.MIN_VALUE;
		int max = bigMax.intValue();
		for (Node a : this.getNodeList()) {
			if (a.getOutgoingEdges().size() > max) {
				max = a.getOutgoingEdges().size();
			}
		}
		return max;
	}

	//Find all nodes with largest outdegree.
	public String maxOutgoingEdges() {
		String maxEdgeNodes = "";
		ArrayList<Node> maxEdges = new ArrayList<Node>();

		for (Node a : this.getNodeList()) {
			if (a.getOutgoingEdges().size() >= this.findMaxOutdegree()) {
				maxEdges.add(a);
			}
		}
		if (maxEdges.size() == 1) {
			return maxEdges.get(0).getAbbrev();
		} else {
			for (Node a : maxEdges) {
				maxEdgeNodes += a.getAbbrev() + ", ";
			}

			maxEdgeNodes = maxEdgeNodes.substring(0, maxEdgeNodes.length() - 2);

			return maxEdgeNodes;
		}
	}

	//Print max outgoing degree nodes.
	public String printMaxOutgoingNodes() {
		String info = "";
		//Checking if there is one or more nodes with outgoing degrees for proper output.
		if ((this.countMaxOutgoingDegreeNodes() < 1) || (this.countMaxOutgoingDegreeNodes() == this.getNodeList().size())) {
			info += "No node has the highest outdegree.\n";
		} else if (this.countMaxOutgoingDegreeNodes() > 1) {
			info += "Nodes " + this.maxOutgoingEdges() + " have the most outgoing edges (" + this.findMaxOutdegree() + ").\n";
		}
		else if (this.countMaxOutgoingDegreeNodes() == 1) {
			info += "Node " + this.maxOutgoingEdges() + " has the most outgoing edges (" + this.findMaxOutdegree() + ").\n";
		}
		return info;
	}

	//Print maximum distance edge information.
	public String printMaxEdge() {
		String info = "";
		ArrayList<Edge> maxEdges = findMaxEdge();
		if ((maxEdges.size() < 1) || (maxEdges.size() == getNodeList().size())) {
			return info += "There is no longest edge.\n";
		} else if (maxEdges.size() > 1) {
			info += "The longest edges are ";
			for (Edge e : maxEdges) {
				info += e.getHead().getAbbrev() + "" + e.getTail().getAbbrev() + ", ";
			}
			info = info.substring(0, info.length() - 2);
			info += " (" + this.findMaxEdgeDist() + ").\n";

		}

		return info;
	}

	//Print minimum edge distance information
	public String printMinEdge() {
		String result = "";
		ArrayList<Edge> minEdges = findMinEdge();
		if ((minEdges.size() < 1) || (minEdges.size() == this.getNodeList().size())) {
			return result += "There is no shortest edge.\n";
		} else if (minEdges.size() >= 1) {
			result += "The shortest edge(s) is/are ";
			for (Edge e : minEdges) {
				result += e.getHead().getAbbrev() + "" + e.getTail().getAbbrev() + ", ";
			}
			result = result.substring(0, result.length() - 2);
			result += " (" + this.findMinEdgeDist() + ").";
		}
		return result;
	}

	//Print graph information.
	public String printGraphInfo() {
		String info = "";
		info += "There are " + this.getNodeList().size() + " nodes in the graph.\n";
		info += "There are " + this.getEdgeList().size() + " edges in the graph.\n";
		info += this.printMaxOutgoingNodes();
		info += this.printMaxEdge();
		info += this.printMinEdge();
		return info;
	}

	public String printGraphNodes() {
		String info = "";
		for (Node a : this.getNodeList()) {
			info += a.toString();
		}
		return info;
	}


}


